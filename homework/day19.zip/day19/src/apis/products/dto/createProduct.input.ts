import { Field, InputType, Int } from '@nestjs/graphql';
import { Min } from 'class-validator';
import { ProductLocalInput } from 'src/apis/productsLocals/dto/productLocal.input';
import { UserInput } from 'src/apis/users/dto/productUser.input';

@InputType()
export class CreateProductInput {
  @Field(() => String)
  name: string;

  @Field(() => String)
  description: string;

  @Min(0)
  @Field(() => Int)
  price: number;

  @Field(() => ProductLocalInput)
  productLocal: ProductLocalInput;

  // @Field(() => UserInput)
  // userInput: UserInput;

  @Field(() => String)
  productCategoryId: string;
}
