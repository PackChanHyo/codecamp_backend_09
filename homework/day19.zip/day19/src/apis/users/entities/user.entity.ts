import { Field, Int, ObjectType } from '@nestjs/graphql';
import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity()
@ObjectType()
export class User {
  @PrimaryGeneratedColumn('uuid')
  @Field(() => String)
  id: string;

  @Column()
  @Field(() => String)
  name: string;

  @Column()
  @Field(() => String)
  userId: string;

  @Column()
  @Field(() => Int)
  pwd: number;

  @Column()
  @Field(() => Int)
  phone: number;

  @Column()
  @Field(() => String)
  email: string;

  @Column({ default: false })
  @Field(() => Boolean)
  emailsign: boolean;

  @Column()
  @Field(() => Date)
  date: Date;

  @Column()
  @Field(() => Int)
  memberSince: number;

  @Column()
  @Field(() => Int)
  point: number;

  @Column()
  @Field(() => String)
  online: string;

  @Column()
  @Field(() => String)
  personal: string;

  @Column()
  @Field(() => String)
  membership: string;
}
