import { ConflictException, Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { User } from './entities/user.entity';

@Injectable()
export class UsersService {
  constructor(
    @InjectRepository(User)
    private readonly userRepository: Repository<User>,
  ) {}
  async create({ userInput }) {
    const { ...user } = userInput;
    const reuslt = await this.userRepository.save({
      ...user,
    });
    return reuslt;
  }
}
